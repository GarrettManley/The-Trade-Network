
public interface OnChangeSize {
	public void changeSize(int x, int y);
}
